﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlatformerSpeedRunner.Enum
{
    public enum Fonts
    {
        CalibriBold25,
        CalibriBold50
    }
}
