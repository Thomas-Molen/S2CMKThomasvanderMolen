﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlatformerSpeedRunner.Enum
{
    public enum CameraMode
    {
        Free,
        Horizontal,
        Vertical,
        None
    }
}
