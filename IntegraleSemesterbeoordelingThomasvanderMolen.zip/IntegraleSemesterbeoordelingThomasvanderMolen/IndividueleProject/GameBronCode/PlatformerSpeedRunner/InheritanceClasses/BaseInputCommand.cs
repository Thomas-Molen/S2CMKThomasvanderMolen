﻿namespace PlatformerSpeedRunner.Input.Base
{
    public class BaseInputCommand
    {
    }
}
