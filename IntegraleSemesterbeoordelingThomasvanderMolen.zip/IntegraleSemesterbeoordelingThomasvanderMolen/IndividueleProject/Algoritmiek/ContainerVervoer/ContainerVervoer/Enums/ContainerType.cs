﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ContainerVervoer.Enums
{
    public enum ContainerType
    {
        Normal,
        Cooled,
        Valueable
    }
}
