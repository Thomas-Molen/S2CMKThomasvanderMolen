﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ContainerVervoer.Enums
{
    public enum ShipPosition
    {
        First,
        Middle,
        Last
    }
}
