﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CircusTreinV2.Enums
{
    public enum AnimalType
    {
        Herbivore,
        Carnivore
    }
}
