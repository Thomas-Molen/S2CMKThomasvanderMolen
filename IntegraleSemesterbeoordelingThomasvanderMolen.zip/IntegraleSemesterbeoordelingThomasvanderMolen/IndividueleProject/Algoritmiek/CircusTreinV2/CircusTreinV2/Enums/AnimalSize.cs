﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CircusTreinV2.Enums
{
    public enum AnimalSize
    {
        Small = 1,
        Medium = 3,
        Large = 5
    }
}
